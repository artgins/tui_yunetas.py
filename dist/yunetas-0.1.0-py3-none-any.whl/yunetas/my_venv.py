import typer

app = typer.Typer()


@app.command()
def create(venv_name: str):
    print(f"Creating venv: {venv_name}")


@app.command()
def delete(venv_name: str):
    print(f"Deleting venv: {venv_name}")


if __name__ == "__main__":
    app()
