import sys

if __name__ == '__main__':
    from yunetas import run

    sys.exit(run())

