import sys
from .main import app

if __name__ == "__main__":
    sys.exit(app(prog_name="yunetas"))
